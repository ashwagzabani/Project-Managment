import React, { Component } from 'react';

class MemberDetails extends Component {
    render() {
        return (
            <div>
                
            </div>
        );
    }
}

export default MemberDetails;
